# Core-3.1 - Login and Registration using Identity in ASP.NET Core 3.1

For documentation and instructions check out  - https://www.freecodespot.com/blog/asp-net-core-identity/
